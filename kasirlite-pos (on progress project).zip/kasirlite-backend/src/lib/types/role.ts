export type Role = {
  id: number;
  name: string;
};
