export type PaymentType = {
  id: number;
  name: string;
  tax: number;
};
