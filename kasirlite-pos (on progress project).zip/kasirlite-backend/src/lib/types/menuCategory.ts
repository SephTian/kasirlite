export type MenuCategory = {
  id: number; // dri BE
  name: string;
  isAdditional: boolean;
};
