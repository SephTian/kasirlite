export const TAX = 0.12;
